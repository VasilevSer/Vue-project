<template>
    <div class="page-container">
      <div class="accordion-container">
        <div v-for="(item, index) in items" :key="index" class="accordion-item">
          <div class="accordion-header" @click="toggle(index)">
            <img :src="item.image" alt="icon" class="accordion-icon" />
            <span>{{ item.title }}</span>
          </div>
          <div v-if="activeIndex === index" class="accordion-content">
            {{ item.content }}
          </div>
        </div>
      </div>
      <button class="close-btn" @click="openImage">✖</button>
      <div v-if="showImage" class="modal" @click="showImage = false">
        <img :src="modalImage" alt="modal" class="modal-content" />
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        activeIndex: null,
        showImage: false,
        modalImage: 'https://i.pinimg.com/474x/30/ec/f6/30ecf6f5251eb77b1a19baa58968d275.jpg',
        items: [
          {
            title: 'Аккордеон 1 - Синицы',
            content: 'Большая синица (лат. Parus major) — широко распространённая птица из семейства синицевых, отряда воробьинообразных. Обитает на всей территории Европы, Ближнего Востока, Центральной и Северной Азии, в некоторых районах Северной Африки. В дикой природе встречается в разнообразных лесах, обычно на открытых участках, опушках, по берегам водоёмов. Это, как правило, неперелётные птицы, и большинство больших синиц не мигрирует, кроме очень суровых зим. Синица выделяется чёрной головой и шеей, бросающимися в глаза белыми щеками, оливковым верхом и жёлтым низом. Летом питается преимущественно мелкими насекомыми и другими беспозвоночными. Зимой переходит на более разнообразный корм.',
            image: 'https://i.pinimg.com/474x/ce/28/d0/ce28d0c2a3ec5625517abe4b0256ed2f.jpg' 
          },
          {
            title: 'Аккордеон 2 - Воробьи',
            content: 'Воробьи — мелкие птицы с коричнево-бурым оперением. Их рост — 14–18 см, вес — 21–37 г, размах крыльев — 19–25 см. Самцы отличаются серой кепочкой и чёрным галстуком, размер которого указывает на его статус. Воробьи преимущественно оседлые птицы. Они чаще не покидают места своего обитания в зависимости от сезона. Некоторые могут откочёвывать, но не далее чем на несколько километров. Воробьи строят гнёзда в различных нишах строений, на чердаках, в дуплах деревьев, в норах, обживают покинутые чужие гнёзда и скворечники. Могут поселиться в зарослях деревьев и кустарников, в оврагах, на обрывах. Питаются воробьи в основном семенами. Обожают подсолнечник, коноплю, пшеничные зёрна. Своих птенцов воробьи кормят мясом, бабочками, гусеницами.',
            image: '	https://i.pinimg.com/474x/d3/27/a5/d327a54c853f9ac8b987b0baea3578c5.jpg' 
          },
          {
            title: 'Аккордеон 3 - Грачи',
            content: 'Грач (лат. Corvus frugilegus) — широко распространённый в Евразии вид птиц рода воронов. Длина грача составляет 45–47 см, масса взрослой особи — от 280 до 340 г, размах крыльев — от 81 до 99 см. Перья чёрные, с фиолетовым отливом. Грачи всеядны, но главным образом питаются червями и личинками насекомых, которых они находят, копаясь в земле своим крепким клювом. В северной части ареала грачи — перелётные птицы, в южной — оседлые. Гнездятся на деревьях большими колониями.',
            image: 'https://i.pinimg.com/474x/94/6d/b2/946db28513df3d603c321fb715f60d58.jpg' 
          }
        ]
      };
    },
    methods: {
      toggle(index) {
        this.activeIndex = this.activeIndex === index ? null : index;
      },
      openImage() {
        this.showImage = true;
      }
    }
  };
  </script>
  
  <style scoped>
  .page-container {
    background-color: #40e0d0;
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .accordion-container {
    background-color: #0000ff;
    padding: 20px;
    border-radius: 10px;
    color: white;
    width: 400px;
  }
  
  .accordion-item {
    margin-bottom: 10px;
  }
  
  .accordion-header {
    display: flex;
    align-items: center;
    cursor: pointer;
    padding: 10px;
    background-color: #1e3a8a;
    border-radius: 5px;
  }
  
  .accordion-icon {
    width: 30px;
    height: 30px;
    margin-right: 10px;
  }
  
  .accordion-content {
    padding: 10px;
    background-color: #3b82f6;
    border-radius: 5px;
    margin-top: 5px;
  }
  
  .close-btn {
    position: absolute;
    top: 20px;
    right: 20px;
    background: none;
    border: none;
    font-size: 24px;
    color: white;
    cursor: pointer;
  }
  
  .modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .modal-content {
    max-width: 80%;
    max-height: 80%;
    border-radius: 10px;
  }
  </style>