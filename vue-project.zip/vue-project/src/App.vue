<template>
  <accordion />
</template>

<script>
import accordion from './components/accordion.vue';
export default {
  components: { accordion }
};
</script>

<style>
body {
  margin: 0;
  overflow: hidden;
}
</style>